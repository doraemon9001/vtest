export default {
  CustomerList: 'CustomerList',
  CustomerGet: 'CustomerpAddGet',
  CustomerAddPost: 'CustomerAddPost',
  CustomerEditGet: 'CustomerEditGet',
  CustomerEditPut: 'CustomerEditPut',
  CustomerDelete: 'CustomerDelete',
  GetCustomerList: 'GetCustomerList',
  GetCustomer: 'GetCustomer'
}
