export default {
  GetAuth: 'GetAuth',
  AuthLogin: 'AuthLogin'
}
