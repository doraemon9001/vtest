<template>
  <div>
    <!-- Content Wrapper. Contains page content -->
  <div class="content">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Error
        <p><i class="fa fa-meh-o fa-6" aria-hidden="true"></i></p>
      </h1>
      <ol class="breadcrumb">
        <li>
          </li>
        <li class="active">Error</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <!-- Your Page Content Here -->
      <h2>請正常瀏覽頁面!</h2>
    </section>
  </div>
  </div>
</template>
<script>
  
</script>
